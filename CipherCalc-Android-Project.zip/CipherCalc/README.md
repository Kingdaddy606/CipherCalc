# CipherCalc — Android encrypted vault starter

CipherCalc presents a calculator first. On first launch, create a 4–12 digit PIN in the setup dialog. Later, enter that PIN on the calculator and press `=` to unlock the vault. Incorrect numeric input falls back to calculator behavior.

## Features
- Android-native APK; minimum Android 8.0 (API 26)
- Dark calculator interface and private-vault interface
- Import images, videos, and audio through Android's system file picker
- AES-256-GCM authenticated encryption with a random IV per imported file
- PBKDF2-HMAC-SHA256 PIN-based key derivation (210,000 iterations)
- Files stored in app-private internal storage; no broad storage permission
- Open/export a decrypted copy via Android's Save As picker
- Delete encrypted files from the vault
- GitHub Actions builds a debug APK and uploads it as an artifact

## Build on GitHub from an Android phone
1. Create a GitHub repository named `CipherCalc`.
2. Upload the contents of this folder to the repository root, including the hidden `.github/workflows/build-apk.yml` file.
3. Open the repository's **Actions** tab.
4. Select **Build CipherCalc APK** and tap **Run workflow** (or push a commit to `main`/`master`).
5. Open the completed run, find **Artifacts**, and download `CipherCalc-debug-apk`.
6. Extract the ZIP artifact on your phone and install `app-debug.apk`. Android may ask you to allow installation from that source.

## Important security and engineering notes
- This is a starter implementation, not a professionally audited security product. Test with disposable copies before trusting important files.
- Do not forget your PIN: the files cannot be recovered without it. Reinstalling the app or clearing its data removes the app-private vault.
- Imported content is currently read into memory before encryption, and export decrypts into memory. Very large videos may fail on phones with limited RAM. A production release should use streaming encryption/decryption and a recovery/export strategy.
- File names and MIME types are stored in app preferences as metadata; the actual file contents are encrypted. A hardened version should encrypt metadata too and add a verified PIN-change flow, rate limiting, and secure key handling.
- Android backup is disabled in the manifest, and the app does not upload files to any server.
- The calculator is a privacy interface, not a guarantee against forensic extraction, rooted devices, malware, screen recording, or someone who knows your PIN.
- Build output is a debug APK. A release APK should be signed securely before public distribution.
