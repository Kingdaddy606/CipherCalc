package com.ciphercalc.vault

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 19, 21)
    private val panel = Color.rgb(28, 33, 36)
    private val mint = Color.rgb(66, 214, 181)
    private val white = Color.rgb(245, 247, 247)
    private val muted = Color.rgb(154, 166, 168)
    private val prefs by lazy { getSharedPreferences("ciphercalc", MODE_PRIVATE) }
    private var displayText = "0"
    private var unlockedKey: SecretKey? = null
    private var vaultMode = false
    private var currentCategory = "All"
    private val requestImport = 501

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        File(filesDir, "cipher_vault").mkdirs()
        showCalculator()
        if (!prefs.contains("salt")) showPinSetup()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(16)); setBackgroundColor(bg)
        layoutParams = ViewGroup.LayoutParams(-1, -1)
    }
    private fun text(s: String, size: Float, color: Int = white, bold: Boolean = false): TextView = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); gravity = Gravity.CENTER_VERTICAL
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun button(s: String, color: Int = panel, textColor: Int = white, action: () -> Unit): TextView = TextView(this).apply {
        text = s; textSize = 18f; gravity = Gravity.CENTER; setTextColor(textColor); setBackgroundColor(color)
        isClickable = true; isFocusable = true; setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(0, dp(58), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
    }
    private fun row(root: LinearLayout, vararg views: View) { val r = LinearLayout(this); r.orientation = LinearLayout.HORIZONTAL; views.forEach { r.addView(it) }; root.addView(r) }

    private fun showCalculator() {
        vaultMode = false
        val root = base()
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(text("◈  CIPHERCALC", 15f, mint, true), LinearLayout.LayoutParams(0, dp(44), 1f))
        top.addView(text("PRIVATE MODE", 10f, muted, true))
        root.addView(top)
        root.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        val display = text(displayText, 42f, white, false).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL; maxLines = 2; setPadding(dp(4), dp(16), dp(4), dp(16)) }
        root.addView(display, LinearLayout.LayoutParams(-1, dp(110)))
        root.addView(text("Enter your PIN and press = to open private files", 12f, muted).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(-1, dp(28)))
        val keys = arrayOf(arrayOf("AC", "⌫", "%", "÷"), arrayOf("7", "8", "9", "×"), arrayOf("4", "5", "6", "−"), arrayOf("1", "2", "3", "+"), arrayOf("0", ".", "00", "="))
        keys.forEach { line ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            line.forEach { k ->
                val special = k in listOf("÷", "×", "−", "+", "=")
                val b = button(k, if (special) mint else panel, if (special) bg else white) { onCalculatorKey(k, display) }
                r.addView(b)
            }
            root.addView(r)
        }
        root.addView(View(this), LinearLayout.LayoutParams(1, 0, .45f))
        root.addView(text("Your files stay encrypted in app-private storage", 11f, muted).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, dp(26)))
        setContentView(root)
    }

    private fun onCalculatorKey(k: String, display: TextView) {
        when (k) {
            "AC" -> displayText = "0"
            "⌫" -> displayText = if (displayText.length <= 1) "0" else displayText.dropLast(1)
            "=" -> {
                if (prefs.contains("salt") && displayText.all { it.isDigit() } && displayText.length in 4..12) {
                    if (unlockVault()) return
                }
                try {
                    val result = evaluate(displayText)
                    displayText = if (result.isFinite()) result.toString().removeSuffix(".0") else "Error"
                } catch (_: Exception) { displayText = "Error" }
            }
            else -> displayText = if (displayText == "0" || displayText == "Error") k else displayText + k
        }
        display.text = displayText
    }

    private fun evaluate(input: String): Double {
        val clean = input.replace("×", "*").replace("÷", "/").replace("−", "-").replace("%", "/100")
        // Small safe arithmetic parser; no code execution or eval.
        val tokens = Regex("(?:\\d+(?:\\.\\d*)?|\\.\\d+|[+*/-])").findAll(clean).map { it.value }.toList()
        require(tokens.isNotEmpty() && tokens.joinToString("") == clean.replace(" ", ""))
        val values = mutableListOf<Double>(); val ops = mutableListOf<String>(); var expectNumber = true
        for (token in tokens) {
            if (token in listOf("+", "-", "*", "/")) {
                if (expectNumber && token in listOf("+", "-")) { values.add(if (token == "-") -1.0 else 1.0); ops.add("*"); expectNumber = true }
                else { require(!expectNumber); ops.add(token); expectNumber = true }
            } else { require(expectNumber); values.add(token.toDouble()); expectNumber = false }
        }
        require(!expectNumber)
        var i = 0
        while (i < ops.size) { if (ops[i] == "*" || ops[i] == "/") { val v = if (ops[i] == "*") values[i] * values[i+1] else values[i] / values[i+1]; values[i] = v; values.removeAt(i+1); ops.removeAt(i) } else i++ }
        var result = values[0]; for (i2 in ops.indices) result = if (ops[i2] == "+") result + values[i2+1] else result - values[i2+1]
        return result
    }

    private fun showPinSetup() {
        val field = EditText(this).apply { hint = "Create a PIN (4–12 digits)"; inputType = 2; setTextColor(white); setHintTextColor(muted) }
        val confirm = EditText(this).apply { hint = "Confirm PIN"; inputType = 2; setTextColor(white); setHintTextColor(muted) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), 0); addView(field); addView(confirm) }
        AlertDialog.Builder(this).setTitle("Set up your private vault").setMessage("Create a PIN. You will enter it on the calculator and press = to unlock the vault.")
            .setView(box).setCancelable(false).setPositiveButton("Create vault", null).create().also { dialog ->
                dialog.setOnShowListener { shown -> (shown as AlertDialog).getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    val a = field.text.toString(); val b = confirm.text.toString()
                    if (a.length !in 4..12 || !a.all { it.isDigit() }) field.error = "Use 4–12 digits"
                    else if (a != b) confirm.error = "PINs do not match"
                    else { createPin(a); dialog.dismiss(); Toast.makeText(this, "Vault created. Enter your PIN in the calculator.", Toast.LENGTH_LONG).show() }
                } }; dialog.show() }
    }

    private fun createPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs.edit().putString("salt", android.util.Base64.encodeToString(salt, android.util.Base64.NO_WRAP)).apply()
        // Verify a PIN without keeping the derived encryption key on disk.
        val key = deriveKey(pin, salt)
        val marker = ByteArray(32).also { SecureRandom().nextBytes(it) }
        val encrypted = crypt(Cipher.ENCRYPT_MODE, key, marker)
        prefs.edit().putString("verifier", android.util.Base64.encodeToString(encrypted, android.util.Base64.NO_WRAP)).apply()
    }

    private fun deriveKey(pin: String, salt: ByteArray): SecretKey {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 210_000, 256)
        val raw = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return SecretKeySpec(raw, "AES")
    }
    private fun crypt(mode: Int, key: SecretKey, input: ByteArray): ByteArray {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(mode, key, GCMParameterSpec(128, iv))
        val out = cipher.doFinal(input)
        return if (mode == Cipher.ENCRYPT_MODE) iv + out else out
    }
    private fun decrypt(key: SecretKey, data: ByteArray): ByteArray {
        val iv = data.copyOfRange(0, 12); val body = data.copyOfRange(12, data.size)
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv)); return c.doFinal(body)
    }
    private fun unlockVault(): Boolean {
        return try {
            val salt = android.util.Base64.decode(prefs.getString("salt", ""), android.util.Base64.DEFAULT)
            val key = deriveKey(displayText, salt)
            val verifier = android.util.Base64.decode(prefs.getString("verifier", ""), android.util.Base64.DEFAULT)
            decrypt(key, verifier)
            unlockedKey = key; displayText = "0"; showVault(); true
        } catch (_: Exception) { false }
    }

    private fun showVault() {
        vaultMode = true
        val root = base()
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(text("◈  PRIVATE VAULT", 20f, white, true), LinearLayout.LayoutParams(0, dp(48), 1f))
        header.addView(button("LOCK", panel, mint) { lockVault() }, LinearLayout.LayoutParams(dp(76), dp(44)))
        root.addView(header)
        root.addView(text("Files are encrypted while stored", 12f, muted), LinearLayout.LayoutParams(-1, dp(28)))
        val import = TextView(this).apply { text = "+  Import photos, videos or audio"; textSize = 15f; gravity = Gravity.CENTER; setTextColor(bg); setBackgroundColor(mint); setPadding(dp(8), 0, dp(8), 0); layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(0, dp(12), 0, dp(12)) }; setOnClickListener { pickFile() } }
        root.addView(import)
        val cats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("All", "Images", "Videos", "Audio").forEach { category ->
            val t = TextView(this).apply { text = category; textSize = 12f; gravity = Gravity.CENTER; setTextColor(if (currentCategory == category) mint else muted); setPadding(dp(8), dp(12), dp(8), dp(12)); setOnClickListener { currentCategory = category; showVault() } }
            cats.addView(t, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        root.addView(cats)
        val scroll = ScrollView(this); val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val files = vaultDir().listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() } ?: emptyList()
        val filtered = files.filter { f -> val type = prefs.getString("type_${f.name}", "file") ?: "file"; when (currentCategory) { "Images" -> type == "image"; "Videos" -> type == "video"; "Audio" -> type == "audio"; else -> true } }
        if (filtered.isEmpty()) list.addView(text("Your vault is empty", 17f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(50), 0, dp(20)) })
        filtered.forEach { file ->
            val name = prefs.getString("name_${file.name}", "Encrypted file") ?: "Encrypted file"
            val type = prefs.getString("type_${file.name}", "file") ?: "file"
            val item = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(8), dp(8), dp(8)); setBackgroundColor(panel) }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(text((when(type){"image"->"▧";"video"->"▶";"audio"->"♫";else->"▤"}) + "  " + name, 14f, white, true))
            info.addView(text("Encrypted • ${android.text.format.Formatter.formatShortFileSize(this@MainActivity, file.length())}", 11f, muted))
            item.addView(info, LinearLayout.LayoutParams(0, dp(54), 1f))
            item.addView(button("OPEN", bg, mint) { exportFile(file) }, LinearLayout.LayoutParams(dp(68), dp(42)))
            item.addView(button("⋮", bg, white) { fileActions(file) }, LinearLayout.LayoutParams(dp(44), dp(42)))
            val lp = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT); lp.setMargins(0, dp(5), 0, dp(5)); list.addView(item, lp)
        }
        scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(text("Private files are not added to your gallery", 11f, muted).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, dp(32)))
        setContentView(root)
    }

    private fun vaultDir() = File(filesDir, "cipher_vault").apply { mkdirs() }
    private fun pickFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*", "audio/*")) }
        startActivityForResult(intent, requestImport)
    }
    @Deprecated("Deprecated in Android API but supported for this simple picker flow")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestImport && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try { encryptImport(uri); showVault(); Toast.makeText(this, "File encrypted and added to vault", Toast.LENGTH_SHORT).show() }
            catch (e: Exception) { Toast.makeText(this, "Import failed: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show() }
        } else if (requestCode == 502 && resultCode == RESULT_OK) {
            val uri = data?.data
            val bytes = pendingExport
            if (uri != null && bytes != null) {
                try { contentResolver.openOutputStream(uri)?.use { it.write(bytes) }; Toast.makeText(this, "Decrypted copy saved", Toast.LENGTH_SHORT).show() }
                catch (_: Exception) { Toast.makeText(this, "Could not save the copy", Toast.LENGTH_LONG).show() }
                finally { bytes.fill(0); pendingExport = null }
            }
        }
    }
    private fun encryptImport(uri: Uri) {
        val key = unlockedKey ?: error("Vault is locked")
        val name = queryName(uri).take(100)
        val mime = contentResolver.getType(uri) ?: "application/octet-stream"
        val type = when { mime.startsWith("image/") -> "image"; mime.startsWith("video/") -> "video"; mime.startsWith("audio/") -> "audio"; else -> "file" }
        val id = "${System.currentTimeMillis()}_${java.util.UUID.randomUUID().toString().take(8)}.enc"
        val plain = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Cannot read selected file")
        val encrypted = crypt(Cipher.ENCRYPT_MODE, key, plain)
        FileOutputStream(File(vaultDir(), id)).use { it.write(encrypted) }
        prefs.edit().putString("name_$id", name).putString("type_$id", type).putString("mime_$id", mime).apply()
        plain.fill(0)
    }
    private fun queryName(uri: Uri): String {
        var name = "Imported file"
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) name = c.getString(0) ?: name }
        return name
    }
    private fun exportFile(file: File) {
        val key = unlockedKey ?: return
        AlertDialog.Builder(this).setTitle("Open encrypted file").setMessage("Decrypt this file and save a copy to your phone? The vault copy will remain encrypted.")
            .setNegativeButton("Cancel", null).setPositiveButton("Save copy") { _, _ ->
                try {
                    val bytes = decrypt(key, FileInputStream(file).use { it.readBytes() })
                    val name = prefs.getString("name_${file.name}", "vault-export.bin") ?: "vault-export.bin"
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = prefs.getString("mime_${file.name}", "application/octet-stream") ?: "application/octet-stream"; putExtra(Intent.EXTRA_TITLE, name) }
                    pendingExport = bytes
                    startActivityForResult(intent, 502)
                } catch (_: Exception) { Toast.makeText(this, "Could not decrypt this file", Toast.LENGTH_LONG).show() }
            }.show()
    }
    private var pendingExport: ByteArray? = null
    private fun fileActions(file: File) {
        AlertDialog.Builder(this).setTitle(prefs.getString("name_${file.name}", "Encrypted file") ?: "Encrypted file")
            .setItems(arrayOf("Save decrypted copy to phone", "Delete from vault")) { _, which -> if (which == 0) exportFile(file) else confirmDelete(file) }.show()
    }
    private fun confirmDelete(file: File) {
        AlertDialog.Builder(this).setTitle("Delete permanently?").setMessage("This encrypted file will be removed from the vault. Make sure you have another copy if needed.")
            .setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> file.delete(); prefs.edit().remove("name_${file.name}").remove("type_${file.name}").remove("mime_${file.name}").apply(); showVault() }.show()
    }
    private fun lockVault() { unlockedKey = null; currentCategory = "All"; displayText = "0"; showCalculator() }

    override fun onBackPressed() { if (vaultMode) lockVault() else super.onBackPressed() }
}
