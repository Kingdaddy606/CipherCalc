package com.ciphercalc.vault

import android.app.*
import android.os.*
import android.content.*
import android.graphics.Color
import android.graphics.BitmapFactory
import android.net.Uri
import android.view.*
import android.widget.*
import android.text.InputType
import android.util.Base64
import android.provider.OpenableColumns
import android.provider.DocumentsContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.security.KeyStore
import java.security.SecureRandom
import java.util.concurrent.Executor
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.crypto.*
import javax.crypto.spec.*
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

class MainActivity : AppCompatActivity() {
    private val bg = Color.rgb(0, 0, 0)
    private val panel = Color.rgb(17, 17, 19)
    private val panel2 = Color.rgb(34, 34, 37)
    private val mint = Color.rgb(245, 245, 247)
    private val white = Color.rgb(248, 248, 250)
    private val muted = Color.rgb(157, 157, 164)
    private val prefs by lazy { getSharedPreferences("ciphercalc_secure", MODE_PRIVATE) }
    private var master: ByteArray? = null
    private var page = "Home"
    private var query = ""
    private var folderFilter = ""
    private var sortMode = "Newest first"
    private val selected = linkedSetOf<String>()
    private var calcEntry = ""
    private var calcOperator = ""
    private var calcFirst = 0.0
    private var isCalculatorOperation = false
    private var lastWasResult = false
    private var lastBackground = 0L
    private val handler = Handler(Looper.getMainLooper())
    private var lastInteraction = System.currentTimeMillis()
    private val pick = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val key = master?.copyOf()
        if (key == null) { showCalculator(); return@registerForActivityResult }
        val chosen = uris ?: emptyList()
        if (chosen.isEmpty()) return@registerForActivityResult
        toast("Importing ${chosen.size} file(s)…")
        Thread {
            var imported = 0
            var originalsDeleted = 0
            var deleteFailed = 0
            chosen.forEach { uri ->
                val wasImported = importUri(uri, key)
                if (wasImported) {
                    imported++
                    // For document-type files, remove the original only after the encrypted copy
                    // and its metadata have been saved successfully. Providers may deny deletion.
                    if (isDocumentUri(uri)) {
                        try {
                            if (DocumentsContract.isDocumentUri(this, uri) &&
                                DocumentsContract.deleteDocument(contentResolver, uri)) originalsDeleted++
                            else deleteFailed++
                        } catch (_: Exception) { deleteFailed++ }
                    }
                }
            }
            key.fill(0)
            runOnUiThread {
                showVault()
                val message = if (deleteFailed == 0) {
                    "Imported $imported file(s). Original documents removed: $originalsDeleted."
                } else {
                    "Imported $imported file(s). Removed $originalsDeleted original document(s); $deleteFailed could not be removed by the storage provider."
                }
                toast(message)
            }
        }.start()
    }
    private fun isDocumentUri(uri: Uri): Boolean {
        val mime = try { contentResolver.getType(uri)?.lowercase().orEmpty() } catch (_: Exception) { "" }
        return !mime.startsWith("image/") && !mime.startsWith("video/") && !mime.startsWith("audio/")
    }

    private val openDoc = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) promptBackupPassword(uri, restore = true)
    }
    private val exportRecoveryDoc = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            val text = prefs.getString("recoveryDisplay", "") ?: ""
            contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
            toast("Recovery key exported")
        }
    }
    private val exportBackupDoc = registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) promptBackupPassword(uri, restore = false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        showCalculator()
        handler.post(object : Runnable {
            override fun run() {
                if (master != null && prefs.getBoolean("autoLock", true) &&
                    System.currentTimeMillis() - lastInteraction > autoLockMillis()) {
                    lockVault()
                }
                handler.postDelayed(this, 5000)
            }
        })
    }

    override fun onResume() {
        super.onResume()
        if (master != null && prefs.getBoolean("autoLock", true) && lastBackground > 0 &&
            System.currentTimeMillis() - lastBackground > autoLockMillis()) lockVault()
        lastBackground = 0L
    }

    override fun onStop() {
        super.onStop()
        lastBackground = System.currentTimeMillis()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        lastInteraction = System.currentTimeMillis()
        return super.dispatchTouchEvent(ev)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(14), dp(18), dp(12))
        setBackgroundColor(bg)
    }
    private fun text(s: String, size: Float = 16f, color: Int = white, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(dp(2), dp(5), dp(2), dp(5))
        }
    private fun button(s: String, action: () -> Unit): Button = Button(this).apply {
        text = s; textSize = 12f; isAllCaps = false; setTextColor(bg)
        backgroundTintList = android.content.res.ColorStateList.valueOf(mint)
        setPadding(dp(4), 0, dp(4), 0)
        setOnClickListener { lastInteraction = System.currentTimeMillis(); action() }
    }
    private fun softButton(s: String, action: () -> Unit): Button = Button(this).apply {
        text = s; textSize = 12f; isAllCaps = false; setTextColor(white)
        backgroundTintList = android.content.res.ColorStateList.valueOf(panel2)
        setPadding(dp(4), 0, dp(4), 0)
        setOnClickListener { lastInteraction = System.currentTimeMillis(); action() }
    }
    private fun add(root: LinearLayout, v: View, h: Int = -2) {
        root.addView(v, LinearLayout.LayoutParams(-1, h).apply { bottomMargin = dp(7) })
    }
    private fun input(hint: String, numeric: Boolean = false): EditText = EditText(this).apply {
        this.hint = hint; setTextColor(white); setHintTextColor(muted); setSingleLine()
        setPadding(dp(12), dp(10), dp(12), dp(10)); backgroundTintList = android.content.res.ColorStateList.valueOf(mint)
        if (numeric) inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
    }
    private fun toast(s: String) { runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() } }
    private fun lockVault() { master?.fill(0); master = null; selected.clear(); query = ""; folderFilter = ""; showCalculator() }

    // Discreet, compact calculator: full expression at the top, live result below.
    // A numeric-only expression followed by '=' retains the existing hidden unlock gesture.
    private fun showCalculator() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(8), dp(18), dp(6))
            setBackgroundColor(bg)
            fitsSystemWindows = true
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), 0, dp(2), dp(4))
        }
        val brand = TextView(this).apply {
            text = android.text.SpannableString("CipherCalc").apply {
                setSpan(android.text.style.ForegroundColorSpan(white), 0, 6, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                setSpan(android.text.style.ForegroundColorSpan(muted), 6, length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            textSize = 22f
            setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL))
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(brand, LinearLayout.LayoutParams(0, dp(42), 1f))
        // No vault labels, PIN instructions, or private-storage references on this screen.
        root.addView(header, LinearLayout.LayoutParams(-1, dp(44)))

        val displayCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                setColor(Color.rgb(9, 9, 10))
                setStroke(dp(1), Color.rgb(42, 42, 46))
            }
        }
        val expressionScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            fillViewport = false
        }
        val expression = TextView(this).apply {
            textSize = 21f
            setTextColor(muted)
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            maxLines = 1
            setPadding(0, 0, 0, dp(3))
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
        }
        expressionScroll.addView(expression, HorizontalScrollView.LayoutParams(-2, dp(34)))
        val result = TextView(this).apply {
            text = "0"
            textSize = 35f
            setTextColor(white)
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.START
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            setPadding(0, dp(2), 0, 0)
        }
        displayCard.addView(expressionScroll, LinearLayout.LayoutParams(-1, dp(36)))
        displayCard.addView(result, LinearLayout.LayoutParams(-1, dp(47)))
        root.addView(displayCard, LinearLayout.LayoutParams(-1, dp(94)).apply {
            topMargin = dp(8)
            bottomMargin = dp(12)
        })

        val rows = listOf(
            listOf("C", "⌫", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"),
            listOf("◎", "0", ".", "=")
        )
        rows.forEach { labels ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            labels.forEach { label ->
                val keyView = TextView(this).apply {
                    text = label
                    textSize = if (label == "◎" || label == "⌫") 20f else 22f
                    gravity = Gravity.CENTER
                    setTextColor(if (label == "=") Color.BLACK else if (label in listOf("÷", "×", "−", "+", "%", "C", "⌫")) white else white)
                    typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
                    background = android.graphics.drawable.GradientDrawable().apply {
                        cornerRadius = dp(17).toFloat()
                        setColor(when {
                            label == "=" -> Color.rgb(245, 245, 247)
                            label in listOf("÷", "×", "−", "+", "%", "C", "⌫") -> Color.rgb(38, 38, 42)
                            else -> Color.rgb(24, 24, 27)
                        })
                        setStroke(dp(1), Color.rgb(39, 39, 43))
                    }
                    isClickable = true
                    isFocusable = true
                    setOnClickListener {
                        lastInteraction = System.currentTimeMillis()
                        if (label == "=") calculatorEquals(expression, result, expressionScroll)
                        else calculatorKey(label, expression, result, expressionScroll)
                    }
                }
                row.addView(keyView, LinearLayout.LayoutParams(0, dp(51), 1f).apply {
                    marginStart = dp(4)
                    marginEnd = dp(4)
                })
            }
            root.addView(row, LinearLayout.LayoutParams(-1, dp(51)).apply { bottomMargin = dp(7) })
        }
        // A flexible spacer keeps the keypad compact and clear of Android's bottom gesture bar.
        root.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        setContentView(root)
        calcEntry = ""
        calcOperator = ""
        isCalculatorOperation = false
        lastWasResult = false
        expression.text = ""
        result.text = "0"
    }

    private fun displayNumber(value: Double): String {
        if (!value.isFinite()) return "Error"
        if (value == 0.0) return "0"
        if (value % 1.0 == 0.0 && value >= Long.MIN_VALUE.toDouble() && value <= Long.MAX_VALUE.toDouble()) return value.toLong().toString()
        return java.math.BigDecimal.valueOf(value).stripTrailingZeros().toPlainString().let {
            if (it.length > 18) String.format(java.util.Locale.US, "%.10g", value) else it
        }
    }

    private fun refreshCalculator(expression: TextView, result: TextView, scroll: HorizontalScrollView) {
        expression.text = calcEntry
        val value = evaluateExpression(calcEntry)
        result.text = when {
            calcEntry.isBlank() -> "0"
            value != null && value.isFinite() -> displayNumber(value)
            else -> if (calcEntry.lastOrNull() in listOf('+', '−', '×', '÷', '%', '.')) "…" else ""
        }
        scroll.post { scroll.fullScroll(View.FOCUS_RIGHT) }
    }

    private fun calculatorKey(key: String, expression: TextView, result: TextView, scroll: HorizontalScrollView) {
        if (lastWasResult && (key.firstOrNull()?.isDigit() == true || key == ".")) {
            calcEntry = ""
            lastWasResult = false
        }
        when (key) {
            "C" -> { calcEntry = ""; lastWasResult = false }
            "⌫" -> { calcEntry = calcEntry.dropLast(1); lastWasResult = false }
            "◎" -> {
                if (prefs.getBoolean("biometricEnabled", false)) biometricUnlock() else recoverWithKey()
                return
            }
            "." -> {
                val currentNumber = calcEntry.takeLastWhile { it.isDigit() || it == '.' }
                if (!currentNumber.contains('.')) calcEntry += if (currentNumber.isEmpty()) "0." else "."
                lastWasResult = false
            }
            "%", "÷", "×", "−", "+" -> {
                if (calcEntry.isNotBlank() && calcEntry.last() !in listOf('+', '−', '×', '÷', '%')) {
                    calcEntry += key
                    lastWasResult = false
                } else if (key == "−" && calcEntry.isBlank()) {
                    calcEntry = "−"
                    lastWasResult = false
                } else if (calcEntry.isNotBlank()) {
                    calcEntry = calcEntry.dropLast(1) + key
                    lastWasResult = false
                }
            }
            else -> if (key.all { it.isDigit() } && calcEntry.length < 80) {
                calcEntry += key
                lastWasResult = false
            }
        }
        refreshCalculator(expression, result, scroll)
    }

    private fun calculatorEquals(expression: TextView, resultView: TextView, scroll: HorizontalScrollView) {
        val trimmed = calcEntry.trim()
        // Preserve the discreet numeric-only entry behavior without showing PIN-related messages.
        if (trimmed.length in 4..12 && trimmed.all { it.isDigit() }) {
            val secret = trimmed
            calcEntry = ""
            lastWasResult = false
            expression.text = ""
            resultView.text = "0"
            if (!prefs.contains("pinSalt")) setupPin(secret) else unlock(secret)
            return
        }
        val value = evaluateExpression(trimmed)
        if (value != null && value.isFinite()) {
            resultView.text = displayNumber(value)
            lastWasResult = true
        } else if (trimmed.isNotEmpty()) {
            resultView.text = "Error"
        }
        scroll.post { scroll.fullScroll(View.FOCUS_RIGHT) }
    }

    // Small recursive-descent parser; supports precedence, parentheses, decimals and unary minus.
    private fun evaluateExpression(raw: String): Double? {
        if (raw.isBlank()) return null
        val normalized = raw.replace('×', '*').replace('÷', '/').replace('−', '-')
        return try {
            class Parser(private val input: String) {
                private var pos = 0
                private fun skip() { while (pos < input.length && input[pos].isWhitespace()) pos++ }
                private fun eat(c: Char): Boolean { skip(); if (pos < input.length && input[pos] == c) { pos++; return true }; return false }
                fun parse(): Double { val v = expression(); skip(); if (pos != input.length) throw IllegalArgumentException(); return v }
                private fun expression(): Double {
                    var v = term()
                    while (true) { v = when { eat('+') -> v + term(); eat('-') -> v - term(); else -> return v } }
                }
                private fun term(): Double {
                    var v = factor()
                    while (true) {
                        v = when {
                            eat('*') -> v * factor()
                            eat('/') -> { val d = factor(); if (d == 0.0) throw ArithmeticException(); v / d }
                            eat('%') -> { val d = factor(); if (d == 0.0) throw ArithmeticException(); v % d }
                            else -> return v
                        }
                    }
                }
                private fun factor(): Double {
                    skip()
                    if (eat('+')) return factor()
                    if (eat('-')) return -factor()
                    if (eat('(')) { val v = expression(); if (!eat(')')) throw IllegalArgumentException(); return v }
                    skip()
                    val start = pos
                    var dot = false
                    while (pos < input.length && (input[pos].isDigit() || (input[pos] == '.' && !dot))) {
                        if (input[pos] == '.') dot = true
                        pos++
                    }
                    if (start == pos) throw IllegalArgumentException()
                    return input.substring(start, pos).toDouble()
                }
            }
            Parser(normalized).parse().takeIf { it.isFinite() }
        } catch (_: Exception) { null }
    }

    private fun setupPin(pin: String) {
        try {
            val m = randomBytes(32)
            val salt = randomBytes(16)
            val key = derive(pin, salt)
            val recovery = Base64.encodeToString(randomBytes(32), Base64.NO_WRAP)
            val rs = randomBytes(16)
            val editor = prefs.edit()
                .putString("pinSalt", b64(salt))
                .putString("wrappedMaster", b64(seal(key, m)))
                .putString("pinCheck", b64(seal(key, "CipherCalc".toByteArray())))
                .putString("recoverySalt", b64(rs))
                .putString("recoveryWrapped", b64(seal(derive(recovery, rs), m)))
                .putString("recoveryDisplay", recovery)
                .putString("items", "[]")
                .putBoolean("autoLock", true)
                .putString("autoLockMinutes", "2")
                .putBoolean("biometricEnabled", false)
            editor.apply()
            master = m
            AlertDialog.Builder(this).setTitle("Save your recovery key")
                .setMessage("This key can restore access if you lose access to your private files. Copy or export it and store it somewhere safe. It will not be shown again automatically.\n\n$recovery")
                .setPositiveButton("Copy key") { _, _ ->
                    copyText(recovery); showVault()
                }.setNeutralButton("Export key") { _, _ ->
                    exportRecoveryDoc.launch("CipherCalc-recovery-key.txt"); showVault()
                }.setCancelable(false).show()
        } catch (e: Exception) { toast("Vault setup failed: ${e.message}") }
    }

    private fun unlock(pin: String) {
        try {
            val salt = unb64(prefs.getString("pinSalt", "")!!)
            val key = derive(pin, salt)
            val check = open(key, unb64(prefs.getString("pinCheck", "")!!)).decodeToString()
            if (check != "CipherCalc") throw Exception("Wrong PIN")
            master?.fill(0)
            master = open(key, unb64(prefs.getString("wrappedMaster", "")!!))
            page = "Home"; showVault()
        } catch (_: Exception) {
            // Deliberately silent on the calculator screen.
        }
    }

    private fun showVault() {
        if (master == null) { showCalculator(); return }
        val root = base()
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(text("CipherCalc", 24f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(softButton("Lock") { lockVault() }, LinearLayout.LayoutParams(dp(68), dp(44)))
        add(root, header)
        val all = files()
        val totalBytes = (0 until all.length()).sumOf { all.getJSONObject(it).optLong("size") }
        add(root, text("${all.length()} items  •  ${formatBytes(totalBytes)}", 13f, mint))
        val nav = LinearLayout(this)
        listOf("Home", "Photos", "Videos", "Audio", "Settings").forEach { n ->
            val b = if (page == n) button(n) { page = n; showVault() } else softButton(n) { page = n; showVault() }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(3) })
        }
        if (page == "Settings") {
            val settingsScroll = ScrollView(this)
            val settingsContent = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            settingsPage(settingsContent)
            settingsScroll.addView(settingsContent)
            root.addView(settingsScroll, LinearLayout.LayoutParams(-1, 0, 1f))
            add(root, nav)
            setContentView(root)
            return
        }
        if (page == "Home") {
            add(root, text("Your private space", 20f, white, true))
            val cards = LinearLayout(this)
            listOf("Photos", "Videos", "Audio").forEach { category ->
                val count = countType(all, category)
                cards.addView(softButton("$category\n$count") { page = category; showVault() },
                    LinearLayout.LayoutParams(0, dp(76), 1f).apply { marginEnd = dp(4) })
            }
            add(root, cards)
        }
        val search = input("Search by filename")
        search.setText(query)
        search.setOnEditorActionListener { _, _, _ -> query = search.text.toString(); showVault(); true }
        add(root, search)
        val tools = LinearLayout(this)
        tools.addView(button("＋ Import files") { pick.launch(arrayOf("*/*")) }, LinearLayout.LayoutParams(0, dp(44), 1f))
        tools.addView(softButton("Sort") { chooseSort() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        tools.addView(softButton("Folders") { chooseFolder() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        add(root, tools)
        if (selected.isNotEmpty()) {
            val actions = LinearLayout(this)
            actions.addView(softButton("${selected.size} selected") { showBulkMenu() }, LinearLayout.LayoutParams(0, dp(42), 1f))
            actions.addView(button("Bulk actions") { showBulkMenu() }, LinearLayout.LayoutParams(0, dp(42), 1f))
            add(root, actions)
        }
        val scroll = ScrollView(this)
        val listRoot = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val items = filteredItems(all)
        if (items.isEmpty()) add(listRoot, text("No files here yet. Import photos, videos, audio, or documents to get started.", 15f, muted))
        items.forEach { o ->
            val id = o.optString("id")
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(5), dp(4), dp(3), dp(4))
                background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = dp(10).toFloat(); setColor(if (selected.contains(id)) panel2 else panel)
                }
            }
            row.addView(softButton(if (selected.contains(id)) "✓" else "○") {
                if (selected.contains(id)) selected.remove(id) else selected.add(id); showVault()
            }, LinearLayout.LayoutParams(dp(42), dp(46)))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(7), 0, dp(2), 0) }
            info.addView(text("${icon(o.optString("type"))}  ${o.optString("name")}", 14f, white, true))
            info.addView(text("${formatBytes(o.optLong("size"))}  •  ${o.optString("folder", "General")}", 11f, muted))
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(softButton("⋯") { itemMenu(o) }, LinearLayout.LayoutParams(dp(48), dp(44)))
            listRoot.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
        }
        scroll.addView(listRoot)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        add(root, nav)
        setContentView(root)
    }

    private fun settingsPage(root: LinearLayout) {
        add(root, text("Security & storage", 20f, white, true))
        add(root, softButton("Change PIN") { changePin() })
        add(root, softButton("Show / copy recovery key") { showRecoveryKey() })
        add(root, softButton("Recover using recovery key") { recoverWithKey() })
        add(root, softButton(if (prefs.getBoolean("biometricEnabled", false)) "Disable biometric unlock" else "Enable biometric unlock") {
            if (prefs.getBoolean("biometricEnabled", false)) {
                prefs.edit().putBoolean("biometricEnabled", false).apply()
                deleteBiometricKey(); toast("Biometric unlock disabled"); showVault()
            } else enableBiometric()
        })
        add(root, softButton("Auto-lock: ${if (prefs.getBoolean("autoLock", true)) "ON" else "OFF"}") {
            prefs.edit().putBoolean("autoLock", !prefs.getBoolean("autoLock", true)).apply(); showVault()
        })
        add(root, softButton("Auto-lock delay: ${prefs.getString("autoLockMinutes", "2")} minutes") { chooseAutoLock() })
        add(root, softButton("Encrypted backup — export") { exportBackupDoc.launch("CipherCalc-encrypted-backup.ccbak") })
        add(root, softButton("Encrypted backup — restore") { openDoc.launch(arrayOf("application/octet-stream", "*/*")) })
        add(root, softButton("Storage details") {
            val arr = files(); val bytes = (0 until arr.length()).sumOf { arr.getJSONObject(it).optLong("size") }
            AlertDialog.Builder(this).setTitle("Storage")
                .setMessage("Encrypted items: ${arr.length()}\nOriginal media size: ${formatBytes(bytes)}\nEncrypted vault files: ${formatBytes(vaultDiskBytes())}\nTemporary preview files are stored in app-private cache.")
                .setPositiveButton("OK", null).show()
        })
        add(root, softButton("Manage folders") { manageFolders() })
        add(root, softButton("Clear temporary previews") {
            cacheDir.listFiles()?.filter { it.name.startsWith("preview_") || it.name.startsWith("backup_") }?.forEach { it.delete() }
            toast("Temporary files cleared")
        })
        add(root, text("Security note: exported backups are encrypted with a separate password. Keep both your PIN/recovery key and backup password safe. Clearing app data or uninstalling the app deletes the local vault.", 12f, muted))
    }

    private fun changePin() {
        val current = input("Current PIN", true)
        val next = input("New PIN (4–12 digits)", true)
        val confirm = input("Confirm new PIN", true)
        val box = LinearLayout(this).apply { orientation = 1; addView(current); addView(next); addView(confirm) }
        AlertDialog.Builder(this).setTitle("Change PIN").setView(box)
            .setPositiveButton("Save") { _, _ ->
                val oldPin = current.text.toString(); val newPin = next.text.toString()
                if (newPin.length !in 4..12 || !newPin.all { it.isDigit() } || newPin != confirm.text.toString()) {
                    toast("New PIN must be 4–12 digits and match confirmation"); return@setPositiveButton
                }
                try {
                    val salt = unb64(prefs.getString("pinSalt", "")!!)
                    val oldKey = derive(oldPin, salt)
                    open(oldKey, unb64(prefs.getString("pinCheck", "")!!))
                    val m = open(oldKey, unb64(prefs.getString("wrappedMaster", "")!!))
                    val ns = randomBytes(16); val nk = derive(newPin, ns)
                    prefs.edit().putString("pinSalt", b64(ns))
                        .putString("wrappedMaster", b64(seal(nk, m)))
                        .putString("pinCheck", b64(seal(nk, "CipherCalc".toByteArray()))).apply()
                    master = m; toast("PIN changed. Encrypted files were not re-encrypted.")
                } catch (_: Exception) { toast("Could not change PIN. Check the current PIN.") }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun recoverWithKey() {
        val keyInput = input("Paste recovery key")
        AlertDialog.Builder(this).setTitle("Recover vault").setMessage("Use the recovery key saved when the vault was created.")
            .setView(keyInput).setPositiveButton("Recover") { _, _ ->
                try {
                    val rs = unb64(prefs.getString("recoverySalt", "")!!)
                    val recoveryKey = derive(keyInput.text.toString().trim(), rs)
                    val recovered = open(recoveryKey, unb64(prefs.getString("recoveryWrapped", "")!!))
                    master = recovered
                    showVault()
                } catch (_: Exception) { toast("Recovery key is invalid") }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showRecoveryKey() {
        val key = prefs.getString("recoveryDisplay", "") ?: ""
        AlertDialog.Builder(this).setTitle("Recovery key")
            .setMessage("Keep this key private. Anyone with it can unlock your vault.\n\n$key")
            .setPositiveButton("Copy") { _, _ -> copyText(key) }
            .setNeutralButton("Export") { _, _ -> exportRecoveryDoc.launch("CipherCalc-recovery-key.txt") }
            .setNegativeButton("Close", null).show()
    }

    private fun enableBiometric() {
        if (!androidx.biometric.BiometricManager.from(this).canAuthenticate(androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG).equals(androidx.biometric.BiometricManager.BIOMETRIC_SUCCESS)) {
            toast("A secure biometric sensor must be enrolled first"); return
        }
        try {
            val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            if (ks.containsAlias(BIO_ALIAS)) ks.deleteEntry(BIO_ALIAS)
            val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            kg.init(KeyGenParameterSpec.Builder(BIO_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setUserAuthenticationRequired(true).setUserAuthenticationValidityDurationSeconds(-1).build())
            kg.generateKey()
            val key = (ks.getKey(BIO_ALIAS, null) as java.security.Key)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key)
            biometricPrompt("Enable biometric unlock", cipher, { c ->
                try {
                    val encrypted = c.doFinal(master ?: throw Exception("Vault locked"))
                    prefs.edit().putString("bioWrapped", b64(c.iv + encrypted)).putBoolean("biometricEnabled", true).apply()
                    toast("Biometric unlock enabled"); showVault()
                } catch (e: Exception) { deleteBiometricKey(); toast("Could not enable biometrics") }
            }, { deleteBiometricKey() })
        } catch (e: Exception) { toast("Biometric setup failed: ${e.message}") }
    }

    private fun biometricUnlock() {
        try {
            val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            val key = ks.getKey(BIO_ALIAS, null) as? java.security.Key ?: throw Exception("No biometric key")
            val wrapped = unb64(prefs.getString("bioWrapped", "")!!)
            if (wrapped.size < 29) throw Exception("Bad biometric data")
            val iv = wrapped.copyOfRange(0, 12)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
            biometricPrompt("Unlock CipherCalc", cipher, { c ->
                try { master = c.doFinal(wrapped.copyOfRange(12, wrapped.size)); page = "Home"; showVault() }
                catch (_: Exception) { toast("Biometric unlock failed") }
            }, { })
        } catch (_: Exception) { toast("Biometric unlock is not available. Use your PIN.") }
    }

    private fun biometricPrompt(title: String, cipher: Cipher, success: (Cipher) -> Unit, failure: () -> Unit) {
        val executor: Executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                result.cryptoObject?.cipher?.let(success)
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { failure() }
        })
        val info = BiometricPrompt.PromptInfo.Builder().setTitle(title)
            .setSubtitle("Authenticate to protect your private files")
            .setAllowedAuthenticators(androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .setNegativeButtonText("Cancel").build()
        prompt.authenticate(info, BiometricPrompt.CryptoObject(cipher))
    }

    private fun deleteBiometricKey() {
        try { KeyStore.getInstance("AndroidKeyStore").apply { load(null); deleteEntry(BIO_ALIAS) } } catch (_: Exception) {}
        prefs.edit().remove("bioWrapped").putBoolean("biometricEnabled", false).apply()
    }

    private fun chooseAutoLock() {
        val options = arrayOf("30 seconds", "1 minute", "2 minutes", "5 minutes", "15 minutes")
        val values = arrayOf("0.5", "1", "2", "5", "15")
        AlertDialog.Builder(this).setTitle("Auto-lock delay").setItems(options) { _, which ->
            prefs.edit().putString("autoLockMinutes", values[which]).apply(); showVault()
        }.show()
    }
    private fun autoLockMillis(): Long = ((prefs.getString("autoLockMinutes", "2")?.toDoubleOrNull() ?: 2.0) * 60_000).toLong()

    private fun chooseSort() {
        val options = arrayOf("Newest first", "Oldest first", "Name A–Z", "Name Z–A", "Largest first", "Smallest first")
        AlertDialog.Builder(this).setTitle("Sort files").setItems(options) { _, which ->
            sortMode = options[which]; showVault()
        }.show()
    }
    private fun chooseFolder() {
        val folders = mutableListOf("All folders", "General")
        try {
            val saved = JSONArray(prefs.getString("folders", "[]"))
            for (i in 0 until saved.length()) if (!folders.contains(saved.getString(i))) folders.add(saved.getString(i))
        } catch (_: Exception) {}
        val arr = files()
        for (i in 0 until arr.length()) {
            val f = arr.getJSONObject(i).optString("folder", "General")
            if (!folders.contains(f)) folders.add(f)
        }
        AlertDialog.Builder(this).setTitle("Filter folder").setItems(folders.toTypedArray()) { _, which ->
            folderFilter = if (which == 0) "" else folders[which]; showVault()
        }.show()
    }
    private fun manageFolders() {
        val name = input("New folder name")
        AlertDialog.Builder(this).setTitle("Create folder").setView(name)
            .setPositiveButton("Create") { _, _ ->
                val f = name.text.toString().trim()
                if (f.isBlank() || f.length > 40) { toast("Enter a folder name up to 40 characters"); return@setPositiveButton }
                val folders = try { JSONArray(prefs.getString("folders", "[]")) } catch (_: Exception) { JSONArray() }
                if ((0 until folders.length()).none { folders.optString(it).equals(f, true) }) folders.put(f)
                prefs.edit().putString("folders", folders.toString()).apply()
                toast("Folder created: $f")
                showVault()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun itemMenu(o: JSONObject) {
        val options = arrayOf("Open privately", "Details", "Move to folder", "Rename", "Delete permanently", "Select")
        AlertDialog.Builder(this).setTitle(o.optString("name")).setItems(options) { _, which ->
            when (which) {
                0 -> openItem(o)
                1 -> showDetails(o)
                2 -> moveToFolder(o)
                3 -> renameItem(o)
                4 -> deleteItem(o)
                5 -> { selected.add(o.optString("id")); showVault() }
            }
        }.show()
    }
    private fun showDetails(o: JSONObject) {
        AlertDialog.Builder(this).setTitle("File details")
            .setMessage("Name: ${o.optString("name")}\nType: ${o.optString("type")}\nSize: ${formatBytes(o.optLong("size"))}\nFolder: ${o.optString("folder", "General")}\nImported: ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(o.optLong("date")))}\nEncryption: AES-256-GCM")
            .setPositiveButton("OK", null).show()
    }
    private fun moveToFolder(o: JSONObject) {
        val folder = input("Folder name", false).apply { setText(o.optString("folder", "General")) }
        AlertDialog.Builder(this).setTitle("Move to folder").setView(folder)
            .setPositiveButton("Save") { _, _ ->
                val f = folder.text.toString().trim().ifBlank { "General" }.take(40)
                rememberFolder(f)
                val arr = files()
                for (i in 0 until arr.length()) if (arr.getJSONObject(i).optString("id") == o.optString("id")) arr.getJSONObject(i).put("folder", f)
                saveItems(arr); showVault()
            }.setNegativeButton("Cancel", null).show()
    }
    private fun renameItem(o: JSONObject) {
        val name = input("New filename").apply { setText(o.optString("name")) }
        AlertDialog.Builder(this).setTitle("Rename item").setView(name)
            .setPositiveButton("Save") { _, _ ->
                val n = name.text.toString().trim()
                if (n.isNotBlank()) {
                    val arr = files()
                    for (i in 0 until arr.length()) if (arr.getJSONObject(i).optString("id") == o.optString("id")) arr.getJSONObject(i).put("name", n.take(180))
                    saveItems(arr); showVault()
                }
            }.setNegativeButton("Cancel", null).show()
    }
    private fun showBulkMenu() {
        val options = arrayOf("Move selected to folder", "Delete selected permanently", "Clear selection")
        AlertDialog.Builder(this).setTitle("${selected.size} selected").setItems(options) { _, which ->
            when (which) {
                0 -> {
                    val folder = input("Folder name")
                    AlertDialog.Builder(this).setTitle("Move selected").setView(folder)
                        .setPositiveButton("Move") { _, _ ->
                            val arr = files(); val f = folder.text.toString().trim().ifBlank { "General" }.take(40); rememberFolder(f)
                            for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); if (selected.contains(o.optString("id"))) o.put("folder", f.take(40)) }
                            saveItems(arr); selected.clear(); showVault()
                        }.setNegativeButton("Cancel", null).show()
                }
                1 -> AlertDialog.Builder(this).setMessage("Permanently delete ${selected.size} selected items?")
                    .setPositiveButton("Delete") { _, _ ->
                        val arr = files()
                        for (i in arr.length() - 1 downTo 0) {
                            val o = arr.getJSONObject(i)
                            if (selected.contains(o.optString("id"))) { File(filesDir, o.optString("id") + ".ccv").delete(); arr.remove(i) }
                        }
                        saveItems(arr); selected.clear(); showVault()
                    }.setNegativeButton("Cancel", null).show()
                2 -> { selected.clear(); showVault() }
            }
        }.show()
    }

    private fun filteredItems(arr: JSONArray): List<JSONObject> {
        val out = mutableListOf<JSONObject>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i); val type = o.optString("type")
            if (page in listOf("Photos", "Videos", "Audio") && type != page) continue
            if (query.isNotBlank() && !o.optString("name").contains(query, true)) continue
            if (folderFilter.isNotBlank() && o.optString("folder", "General") != folderFilter) continue
            out.add(o)
        }
        return when (sortMode) {
            "Oldest first" -> out.sortedBy { it.optLong("date") }
            "Name A–Z" -> out.sortedBy { it.optString("name").lowercase() }
            "Name Z–A" -> out.sortedByDescending { it.optString("name").lowercase() }
            "Largest first" -> out.sortedByDescending { it.optLong("size") }
            "Smallest first" -> out.sortedBy { it.optLong("size") }
            else -> out.sortedByDescending { it.optLong("date") }
        }
    }

    private fun importUri(uri: Uri, key: ByteArray): Boolean {
        try {
            val name = displayName(uri).take(180)
            val reportedSize = displaySize(uri)
            val type = when (contentResolver.getType(uri)?.substringBefore("/")) {
                "image" -> "Photos"; "video" -> "Videos"; "audio" -> "Audio"; else -> "Files"
            }
            val id = System.currentTimeMillis().toString() + "_" + randomBytes(4).joinToString("") { "%02x".format(it) }
            val target = File(filesDir, "$id.ccv")
            contentResolver.openInputStream(uri)?.use { ins ->
                FileOutputStream(target).use { out ->
                    val nonce = randomBytes(12)
                    out.write(nonce)
                    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                    cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
                    CipherOutputStream(out, cipher).use { encrypted -> ins.copyTo(encrypted, 128 * 1024) }
                }
            } ?: throw Exception("Cannot read selected file")
            val arr = files()
            arr.put(JSONObject().put("id", id).put("name", name).put("type", type)
                .put("size", if (reportedSize > 0) reportedSize else (target.length() - 28).coerceAtLeast(0))
                .put("date", System.currentTimeMillis()).put("folder", "General"))
            saveItems(arr)
            return true
        } catch (e: Exception) {
            toast("Import failed: ${e.message}")
            return false
        }
    }

    private fun openItem(o: JSONObject) {
        val key = master?.copyOf()
        if (key == null) { toast("Unlock the vault first"); return }
        toast("Opening privately…")
        Thread {
            val temp = File(cacheDir, "preview_" + o.optString("id"))
            try {
                val encrypted = File(filesDir, o.getString("id") + ".ccv")
                if (!encrypted.exists()) throw Exception("Encrypted file missing")
                FileInputStream(encrypted).use { ins ->
                    val nonce = ByteArray(12)
                    if (ins.read(nonce) != 12) throw Exception("Invalid encrypted file")
                    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                    cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
                    CipherInputStream(ins, cipher).use { dec ->
                        FileOutputStream(temp).use { out -> dec.copyTo(out, 128 * 1024) }
                    }
                }
                runOnUiThread {
                    if (master == null) { temp.delete(); return@runOnUiThread }
                    when (o.optString("type")) {
                        "Photos" -> showImagePreview(o, temp)
                        "Videos" -> showVideoPreview(o, temp)
                        "Audio" -> showAudioPreview(o, temp)
                        else -> { temp.delete(); toast("Unsupported file type") }
                    }
                }
            } catch (e: Exception) {
                temp.delete()
                toast("Unable to open file: ${e.message}")
            } finally { key.fill(0) }
        }.start()
    }

    private fun showImagePreview(o: JSONObject, file: File) {
        val image = ImageView(this).apply { setImageBitmap(BitmapFactory.decodeFile(file.absolutePath)); adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER }
        val scroll = ScrollView(this).apply { addView(image) }
        AlertDialog.Builder(this).setTitle(o.optString("name")).setView(scroll).setPositiveButton("Close") { _, _ -> file.delete() }.setOnCancelListener { file.delete() }.show()
    }
    private fun showVideoPreview(o: JSONObject, file: File) {
        val view = VideoView(this)
        val uri = FileProvider.getUriForFile(this, "$packageName.provider", file)
        view.setVideoURI(uri)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(view, LinearLayout.LayoutParams(-1, dp(250))) }
        val dialog = AlertDialog.Builder(this).setTitle(o.optString("name")).setView(box).setPositiveButton("Close") { _, _ -> view.stopPlayback(); file.delete() }.create()
        dialog.setOnDismissListener { view.stopPlayback(); file.delete() }
        dialog.show(); view.start()
    }
    private fun showAudioPreview(o: JSONObject, file: File) {
        val player = android.media.MediaPlayer()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(12), dp(18), dp(12)) }
        add(box, text("♫  ${o.optString("name")}", 16f, white, true))
        val status = text("Preparing audio…", 13f, muted); add(box, status)
        val controls = LinearLayout(this)
        controls.addView(button("Play / Pause") {
            try { if (player.isPlaying) { player.pause(); status.text = "Paused" } else { player.start(); status.text = "Playing" } } catch (_: Exception) {}
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        controls.addView(softButton("Stop") { try { player.pause(); player.seekTo(0); status.text = "Stopped" } catch (_: Exception) {} }, LinearLayout.LayoutParams(0, dp(48), 1f))
        add(box, controls)
        val dialog = AlertDialog.Builder(this).setTitle("Private audio").setView(box).setPositiveButton("Close", null).create()
        dialog.setOnDismissListener { try { player.stop() } catch (_: Exception) {}; player.release(); file.delete() }
        try {
            player.setDataSource(file.absolutePath)
            player.setOnPreparedListener { status.text = "Ready • ${it.duration / 1000}s"; it.start(); status.text = "Playing" }
            player.setOnCompletionListener { status.text = "Playback complete" }
            player.prepareAsync()
            dialog.show()
        } catch (e: Exception) { player.release(); file.delete(); toast("Audio playback failed: ${e.message}") }
    }

    private fun deleteItem(o: JSONObject) {
        AlertDialog.Builder(this).setMessage("Delete ${o.optString("name")} permanently?")
            .setPositiveButton("Delete") { _, _ ->
                File(filesDir, o.optString("id") + ".ccv").delete()
                val arr = files()
                for (i in arr.length() - 1 downTo 0) if (arr.getJSONObject(i).optString("id") == o.optString("id")) arr.remove(i)
                saveItems(arr); selected.remove(o.optString("id")); showVault()
            }.setNegativeButton("Cancel", null).show()
    }

    // Backup format: password-derived AES-256-GCM wraps a ZIP containing encrypted media files and metadata.
    private fun promptBackupPassword(uri: Uri, restore: Boolean) {
        val pass = input("Backup password (12+ characters)")
        val confirm = if (restore) null else input("Confirm backup password")
        val box = LinearLayout(this).apply { orientation = 1; addView(pass); if (confirm != null) addView(confirm) }
        AlertDialog.Builder(this).setTitle(if (restore) "Restore encrypted backup" else "Create encrypted backup")
            .setMessage("Use a strong password and keep it separately from your vault PIN.")
            .setView(box).setPositiveButton(if (restore) "Restore" else "Encrypt & export") { _, _ ->
                val password = pass.text.toString()
                if (password.length < 12 || (confirm != null && confirm.text.toString() != password)) {
                    toast("Use at least 12 characters and make both passwords match"); return@setPositiveButton
                }
                Thread {
                    try {
                        if (restore) restoreBackupFrom(uri, password) else exportBackupTo(uri, password)
                    } catch (e: Exception) { runOnUiThread { toast("Backup operation failed: ${e.message}") } }
                }.start()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun exportBackupTo(uri: Uri, password: String = "") {
        // Password is requested by promptBackupPassword; an empty password is never accepted.
        if (password.isBlank()) { runOnUiThread { toast("Choose a backup password") }; return }
        val zipFile = File(cacheDir, "backup_${System.currentTimeMillis()}.zip")
        try {
            ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile))).use { zip ->
                val meta = JSONObject()
                listOf("pinSalt", "wrappedMaster", "pinCheck", "recoverySalt", "recoveryWrapped", "recoveryDisplay",
                    "items", "folders", "autoLock", "autoLockMinutes").forEach { k ->
                    if (prefs.contains(k)) {
                        when (k) {
                            "autoLock", "biometricEnabled" -> meta.put(k, prefs.getBoolean(k, false))
                            "autoLockMinutes" -> meta.put(k, prefs.getString(k, "2"))
                            else -> meta.put(k, prefs.getString(k, ""))
                        }
                    }
                }
                zip.putNextEntry(ZipEntry("manifest.json")); zip.write(meta.toString().toByteArray()); zip.closeEntry()
                val arr = files()
                for (i in 0 until arr.length()) {
                    val id = arr.getJSONObject(i).optString("id")
                    val f = File(filesDir, "$id.ccv")
                    if (f.exists()) {
                        zip.putNextEntry(ZipEntry("media/$id.ccv"))
                        FileInputStream(f).use { it.copyTo(zip, 128 * 1024) }
                        zip.closeEntry()
                    }
                }
            }
            val salt = randomBytes(16)
            val key = derive(password, salt)
            val encrypted = File(cacheDir, "backup_${System.currentTimeMillis()}.ccbak")
            FileOutputStream(encrypted).use { out ->
                out.write("CCBK1".toByteArray(Charsets.US_ASCII)); out.write(salt)
                val nonce = randomBytes(12); out.write(nonce)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
                CipherOutputStream(out, cipher).use { cs -> FileInputStream(zipFile).use { it.copyTo(cs, 128 * 1024) } }
            }
            contentResolver.openOutputStream(uri)?.use { out -> FileInputStream(encrypted).use { it.copyTo(out, 128 * 1024) } }
                ?: throw Exception("Could not write backup file")
            encrypted.delete(); zipFile.delete()
            runOnUiThread { toast("Encrypted backup exported") }
        } finally { zipFile.delete() }
    }

    private fun restoreBackupFrom(uri: Uri, password: String) {
        val encrypted = File(cacheDir, "restore_${System.currentTimeMillis()}.ccbak")
        val zipFile = File(cacheDir, "restore_${System.currentTimeMillis()}.zip")
        try {
            contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(encrypted).use { input.copyTo(it, 128 * 1024) } }
                ?: throw Exception("Cannot read selected backup")
            FileInputStream(encrypted).use { ins ->
                val magic = ByteArray(5); if (ins.read(magic) != 5 || String(magic, Charsets.US_ASCII) != "CCBK1") throw Exception("Not a CipherCalc backup")
                val salt = ByteArray(16); if (ins.read(salt) != 16) throw Exception("Invalid backup")
                val nonce = ByteArray(12); if (ins.read(nonce) != 12) throw Exception("Invalid backup")
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(derive(password, salt), "AES"), GCMParameterSpec(128, nonce))
                CipherInputStream(ins, cipher).use { dec -> FileOutputStream(zipFile).use { dec.copyTo(it, 128 * 1024) } }
            }
            val stage = File(cacheDir, "restore_stage").apply { deleteRecursively(); mkdirs() }
            ZipInputStream(BufferedInputStream(FileInputStream(zipFile))).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val out = File(stage, entry.name).canonicalFile
                    if (!out.path.startsWith(stage.canonicalPath + File.separator)) throw Exception("Invalid backup entry")
                    if (entry.isDirectory) out.mkdirs() else {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { zip.copyTo(it, 128 * 1024) }
                    }
                    zip.closeEntry(); entry = zip.nextEntry
                }
            }
            val manifestFile = File(stage, "manifest.json")
            if (!manifestFile.exists()) throw Exception("Backup metadata is missing")
            val meta = JSONObject(manifestFile.readText())
            val arr = JSONArray(meta.optString("items", "[]"))
            // Verify metadata and at least one wrapped key before touching the current vault.
            if (!meta.has("pinSalt") || !meta.has("wrappedMaster") || !meta.has("pinCheck")) throw Exception("Backup is incomplete")
            val mediaDir = File(stage, "media")
            for (i in 0 until arr.length()) {
                val id = arr.getJSONObject(i).optString("id")
                val source = File(mediaDir, "$id.ccv")
                if (!source.exists()) throw Exception("Backup is missing media for ${arr.getJSONObject(i).optString("name")}")
            }
            // Restore only after all archive entries and metadata have been validated.
            filesDir.listFiles()?.filter { it.extension == "ccv" }?.forEach { it.delete() }
            for (i in 0 until arr.length()) {
                val id = arr.getJSONObject(i).optString("id")
                File(mediaDir, "$id.ccv").copyTo(File(filesDir, "$id.ccv"), overwrite = true)
            }
            val editor = prefs.edit().clear()
            val keys = meta.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                when (val v = meta.get(k)) {
                    is Boolean -> editor.putBoolean(k, v)
                    is Number -> editor.putLong(k, v.toLong())
                    else -> editor.putString(k, v.toString())
                }
            }
            editor.putBoolean("biometricEnabled", false).remove("bioWrapped").apply()
            deleteBiometricKey()
            runOnUiThread { master?.fill(0); master = null; selected.clear(); toast("Backup restored. Unlock with the PIN from that backup."); showCalculator() }
        } finally { encrypted.delete(); zipFile.delete(); File(cacheDir, "restore_stage").deleteRecursively() }
    }

    private fun copyText(value: String) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("CipherCalc", value)); toast("Copied to clipboard")
    }
    private fun displayName(uri: Uri): String {
        var name = "media"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) name = it.getString(0) ?: name
        }
        return name
    }
    private fun displaySize(uri: Uri): Long {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
                if (it.moveToFirst()) it.getLong(0).coerceAtLeast(0) else 0L
            } ?: 0L
        } catch (_: Exception) { 0L }
    }
    private fun files(): JSONArray = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
    private fun saveItems(arr: JSONArray) { prefs.edit().putString("items", arr.toString()).apply() }
    private fun rememberFolder(folder: String) {
        val arr = try { JSONArray(prefs.getString("folders", "[]")) } catch (_: Exception) { JSONArray() }
        if ((0 until arr.length()).none { arr.optString(it).equals(folder, true) }) {
            arr.put(folder); prefs.edit().putString("folders", arr.toString()).apply()
        }
    }
    private fun countType(arr: JSONArray, type: String): Int {
        var n = 0; for (i in 0 until arr.length()) if (arr.getJSONObject(i).optString("type") == type) n++; return n
    }
    private fun vaultDiskBytes(): Long = filesDir.listFiles()?.filter { it.extension == "ccv" }?.sumOf { it.length() } ?: 0L
    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        if (bytes < 1024 * 1024) return "%.1f KB".format(bytes / 1024.0)
        if (bytes < 1024L * 1024 * 1024) return "%.1f MB".format(bytes / (1024.0 * 1024))
        return "%.2f GB".format(bytes / (1024.0 * 1024 * 1024))
    }
    private fun derive(s: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(s.toCharArray(), salt, 250_000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }
    private fun seal(key: ByteArray, plain: ByteArray): ByteArray {
        val nonce = randomBytes(12); val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        return nonce + c.doFinal(plain)
    }
    private fun open(key: ByteArray, sealed: ByteArray): ByteArray {
        if (sealed.size < 29) throw Exception("Invalid encrypted data")
        val nonce = sealed.copyOfRange(0, 12); val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        return c.doFinal(sealed.copyOfRange(12, sealed.size))
    }
    private fun randomBytes(n: Int) = ByteArray(n).also { SecureRandom().nextBytes(it) }
    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.NO_WRAP)
    private fun icon(t: String) = when (t) { "Photos" -> "▧"; "Videos" -> "▷"; "Audio" -> "♫"; else -> "•" }
    private fun JSONArray.toListSafe(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }

    companion object { private const val BIO_ALIAS = "ciphercalc_biometric_master_v1" }
}
