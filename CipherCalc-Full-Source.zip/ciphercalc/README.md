# CipherCalc Android project

CipherCalc is a discreet calculator-style Android app with a private encrypted media vault. The launcher label is **Calculator** and the app icon is calculator-themed.

## Features in this source version

- Calculator-style keypad; numeric PIN followed by `=` unlocks the vault. Basic arithmetic keys are included.
- PIN setup and change. The random 256-bit vault master key is wrapped using a PBKDF2-HMAC-SHA256-derived PIN key, so changing the PIN does not re-encrypt media.
- A separate recovery key, with copy/export, and a recovery flow available from the calculator screen using the `◎` key when biometric unlock is not enabled.
- AES-256-GCM encrypted app-private media files. Import and encryption use streaming I/O rather than reading the whole source file into memory.
- Import multiple photos, videos, and audio files through Android's document picker.
- Dark dashboard with mint-green accents and Home / Photos / Videos / Audio / Settings navigation.
- Private photo preview, in-app video playback, and in-app audio playback. Media is decrypted to the app-private cache only while previewing; close the preview or use Settings → Clear temporary previews to clean up.
- Search, sort by name/date/size, folders, file details, rename, move, and bulk move/delete.
- Configurable inactivity/background auto-lock.
- Optional biometric unlock backed by an Android Keystore authentication-bound AES key.
- Encrypted backup export and restore. The backup contains encrypted vault files and key-wrapping metadata, wrapped as a whole with AES-256-GCM using a password-derived key. Use a strong backup password of at least 12 characters and keep it separately from the vault PIN.
- Storage usage display and calculator-style launcher icon.
- GitHub Actions workflow to build a debug APK.

## Build on GitHub from an Android phone

1. Download `CipherCalc-GitHub-Source.zip`.
2. Extract it on your phone, or open it with a ZIP/file-manager app.
3. Upload the **contents of the `ciphercalc` folder** to the root of your GitHub repository. Upload the files/folders themselves, not the ZIP file.
4. Confirm `.github/workflows/build-apk.yml` exists in the repository.
5. Open the repository's **Actions** tab and choose **Build CipherCalc APK**.
6. Tap **Run workflow**. When the job completes, open the run and download the `CipherCalc-debug-apk` artifact.

The standalone workflow file is also supplied separately as `CipherCalc-GitHub-Action.yml`.

## Important safety and test notes

- **This project has not been compiled or run in an Android emulator/device in this environment.** The GitHub Actions build is the first real build check. If it fails, share the failed step and error log so the source can be corrected.
- Test using copies of unimportant sample files first. Do not use the app as the only copy of irreplaceable media until you have tested import, unlock, PIN change, recovery, backup, restore, and playback on your own device.
- Keep the recovery key and backup password safe. Losing the PIN and recovery key may permanently prevent access to the vault.
- Media is encrypted at rest in app-private files. To play or view media, the app decrypts it into its private cache; while the app is previewing media, that temporary plaintext exists on the device. Android may terminate the app or clear cache unexpectedly, so use Settings → Clear temporary previews when needed.
- Backup files are encrypted separately using the backup password. The PIN and recovery key are included only as encrypted key-wrapping metadata inside that password-protected backup.
- Biometric keys are device-bound and are intentionally not included in backups. After restoring on a device, unlock with the backed-up PIN/recovery key and enable biometrics again if desired.
- Android uninstall/data clearing deletes the app-private vault. Export a backup and verify that it restores before relying on it.
- The app does not upload media to a server or require broad shared-storage permissions; the Android document picker grants access to files the user selects.

## Build configuration

- Android Gradle Plugin 8.7.3
- Gradle 8.9 in GitHub Actions
- Kotlin 2.0.21
- Compile SDK 35 / minimum SDK 26 / Java 17
